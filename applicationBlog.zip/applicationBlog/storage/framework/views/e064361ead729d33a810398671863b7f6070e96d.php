<?php /* /home/ashwinig/Documents/PHP_Training/curdblog/resources/views/tasks/show.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-8 blog-main">

<h1 class="title">Show Task</h1>
<form method="POST" action="/tasks/<?php echo e($task->id); ?>">
    <?php echo e(method_field('PATCH')); ?>

    <?php echo e(csrf_field()); ?>

    <div class="field">
        <label class="label" for="employee_name" >employee_name</label>
       <div class="control">
           <input type="text" class="input" name="control" value="<?php echo e($task->employee_name); ?>">
       </div>
    </div>

    <div class="field">
            <label class="label" for="description" >Description</label>
           <div class="control">
               <textarea type="text" class="textarea"><?php echo e($task->description); ?></textarea>
           </div>
        </div>

        <div class="field">
              
               <div class="control">
                  <button type="submit" class="btn btn-info">Update Task</button>
               </div>
            </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>